package br.atos.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.repositorio.CoordenadorRepositorio;
import br.atos.telas.Cadastro;
import br.atos.telas.Listar;

public class MenuInicialControle implements ActionListener {
	
	private JTextField textFieldItemMenu;
	private JFrame frameMenu ;
	
	public MenuInicialControle(JTextField textFieldItemMenu, JFrame frameMenu){
		this.textFieldItemMenu = textFieldItemMenu;
		this.frameMenu = frameMenu;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		this.frameMenu.setVisible(false);
				
		switch (this.textFieldItemMenu.getText()) {
		case "1" : 
			System.out.println("1");
			frameMenu.setVisible(false);			
			Cadastro cadastro = new Cadastro(this.frameMenu);
			cadastro.ExibirTela();
			break;
		case "2" : 
			Listar listar = new Listar(frameMenu);
			listar.ExibirTela();
			break;
		case "3" : 
			System.out.println("3");
			break;
		case "4" :
			System.out.println("3");
			break;
		default:
			System.out.println("Opção inválida.");

	}
}
}