package br.atos.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;

import br.atos.model.Coordenador;

public class CoordenadorDAO {
	
	public boolean Incluir(Coordenador coordenador) {
		String sql = "INSERT INTO funcionario.coordenador (cpf, nome, salario, loja, metaLoja) VALUES( ?,?,?,?,?)";
		boolean retorno  =false;
		
		Connection conn = null;
		PreparedStatement pstm = null;
				
		try {
			
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, coordenador.getCpf());
			pstm.setString(2, coordenador.getCpf());
			pstm.setString(3, coordenador.getCpf());
			pstm.setString(4, coordenador.getCpf());
			pstm.setString(5, coordenador.getCpf());
			
			pstm.execute();
			
			System.out.println("Incluido com sucesso.");
			
			retorno = true;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar inserir.");
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}
			
		}
		return retorno;
	}
}
