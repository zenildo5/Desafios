package br.atos;

import java.sql.Connection;

import br.atos.contraldor.RegistroControlador;
import br.atos.persistencia.FabricaConexao;

public class Principal {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		RegistroControlador registroControlador = new RegistroControlador();
		registroControlador.IniciarPrograma();
		
		/*FabricaConexao conexao = new FabricaConexao();
		Connection conn = FabricaConexao.cirarConexaoMySql();
		if (conn == null) {
			System.out.println("não conectado");
		}else {
			System.out.println("OK");
		}*/
	}

}
