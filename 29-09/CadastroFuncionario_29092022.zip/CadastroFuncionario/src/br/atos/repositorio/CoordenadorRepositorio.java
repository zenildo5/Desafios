package br.atos.repositorio;

import java.util.ArrayList;

import br.atos.model.Coordenador;
import br.atos.persistencia.CoordenadorDAO;

public class CoordenadorRepositorio implements InterfaceReporitorioCoordenador {
	
	static ArrayList<Coordenador> listaCoordenador = new ArrayList<>();
	
	@Override
	public ArrayList<Coordenador> ListarCoordenador() {
		return listaCoordenador;
	}

	@Override
	public void ExcluirCoordenador(String cpf) {
		Coordenador func = new Coordenador();
		
		for(Coordenador item : listaCoordenador) {
			if(item.getCpf().equals(cpf)) {
				func = item;
				break;
			}
		}
		listaCoordenador.remove(func);
		
	}

	@Override
	public Coordenador ObterCoordenador(String cpf) {
		Coordenador func = new Coordenador();
		
		for(Coordenador item : listaCoordenador) {
			if(item.getCpf().equals(cpf)) {
				func = item;
				break;
			}
		}
		return func;
	}

	@Override
	public boolean InserirCoordenador(Coordenador coordenador) {
		try {
			
			CoordenadorDAO dao=new CoordenadorDAO();
			dao.Incluir(coordenador);
			listaCoordenador.add(coordenador);
			System.out.println("Cadastrado");
			return true;
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public void Alterar(Coordenador coordenador) {
		this.ExcluirCoordenador(coordenador.getCpf());
		listaCoordenador.add(coordenador);
	}



}
