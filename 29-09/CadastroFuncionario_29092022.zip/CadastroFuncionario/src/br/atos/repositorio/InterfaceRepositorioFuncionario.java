package br.atos.repositorio;

import java.util.ArrayList;

import br.atos.model.Funcionario;

public interface InterfaceRepositorioFuncionario {
	
	public ArrayList<Funcionario> ListarFuncionario();
	public void ExcluirFuncionario(String cpf);
	public Funcionario ObterFuncionario(String cpf);
	boolean InserirFuncionario(Funcionario funcionario);
	public void Alterar(Funcionario funcionario);
}
