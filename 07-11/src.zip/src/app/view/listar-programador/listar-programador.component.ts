import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Programador } from 'src/app/model/programador';
import { ProgramadorService } from 'src/app/service/programador.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listar-programador',
  templateUrl: './listar-programador.component.html',
  styleUrls: ['./listar-programador.component.css']
})
export class ListarProgramadorComponent implements OnInit {

  programadores : Observable<Programador[]>;

  displayedColumns = ['nome', 'salario', 'idade', 'acao'];

  constructor(public programdorService: ProgramadorService, private router: Router) { 

    this.programadores = programdorService.listarProgamador();//[{id:'1', nome:'doido', salario:'20000',idade:'43'}];

  }

  excluirProgramador(id:Number){
    if(confirm('Tem certeza que deseja excluir o programdor?')){
      console.log(id);
      this.programdorService.excluirProgramador(id).subscribe(res =>{
        console.log(res);
      });
    }    
    this.router.navigate(['/']);
  }

  ngOnInit(): void {
  }

}
