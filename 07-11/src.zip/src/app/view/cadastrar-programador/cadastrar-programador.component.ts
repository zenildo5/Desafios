import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ProgramadorService } from 'src/app/service/programador.service';

@Component({
  selector: 'app-cadastrar-programador',
  templateUrl: './cadastrar-programador.component.html',
  styleUrls: ['./cadastrar-programador.component.css']
})
export class CadastrarProgramadorComponent implements OnInit {
  form!: FormGroup;

  constructor(private programdorService: ProgramadorService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      nome: new FormControl('',[Validators.required]),
      salario: new FormControl('',[Validators.required]),
      idade: new FormControl('',[Validators.required])
    });
  }

  submit(){
    console.log(this.form.value);
    this.programdorService.cadastrarProgramador(this.form.value);
  }

}
