import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ProgramadorService } from 'src/app/service/programador.service';
import { ActivatedRoute } from '@angular/router';
import { Programador } from 'src/app/model/programador';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-editar-programador',
  templateUrl: './editar-programador.component.html',
  styleUrls: ['./editar-programador.component.css']
})
export class EditarProgramadorComponent implements OnInit {

  form!: FormGroup;
  programador!: Programador;
  idProgramador!: number;


  constructor(public programadorService: ProgramadorService,
              private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.idProgramador = this.route.snapshot.params['idProgramador'];
    this.programadorService.obterProgramador(this.idProgramador);
  }

  submit() {
    console.log(this.form.value);
    this.programadorService.alterarProgramador(this.form.value);
  }

}
