export interface Programador {
    id:string,
    nome:string,
    salario:string,
    idade:string
}
