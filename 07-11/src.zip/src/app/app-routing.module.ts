import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './view/home/home.component';
import { CadastrarProgramadorComponent } from './view/cadastrar-programador/cadastrar-programador.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'view/cadastrar', component: CadastrarProgramadorComponent },
  { path: 'view/editar/:idProgramador', component: CadastrarProgramadorComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
