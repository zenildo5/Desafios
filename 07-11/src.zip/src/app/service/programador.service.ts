import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Programador } from '../model/programador';


@Injectable({
  providedIn: 'root'
})
export class ProgramadorService {

  constructor(private httpCliente: HttpClient) { }

  
  listarProgamador(){
    var url = 'http://localhost:8080/api/programadores';
    return this.httpCliente.get<Programador[]>(url);
  }

  obterProgramador(id:Number){
    var url = 'http://localhost:8080/api/obterProgramador/' + id;
    return this.httpCliente.get(url);
  }

  cadastrarProgramador(programador:Programador){
    var url = 'http://localhost:8080/api/inserirProgramador';
    return this.httpCliente.post(url,JSON.stringify(programador));
  }

  alterarProgramador(programador:Programador){
    var url = 'http://localhost:8080/api/alterarProgramador';
    return this.httpCliente.put(url,JSON.stringify(programador));
  }

  excluirProgramador(id:Number){
    var url = 'http://localhost:8080/api/excluirProgramador/' + id;
    return this.httpCliente.delete(url);
  }
}
