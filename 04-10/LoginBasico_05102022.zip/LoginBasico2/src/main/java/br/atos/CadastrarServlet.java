package br.atos;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import br.atos.dataBase.DaoLogin;
import br.atos.model.Login;

/**
 * Servlet implementation class CadastrarServlet
 */
@WebServlet("/Cadastrar")
public class CadastrarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CadastrarServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String usuario = request.getParameter("textUsuario");
		String senha = request.getParameter("textSenha");
		
		DaoLogin daoLogin = new DaoLogin();
		Login login =  new Login();
		login.setUsuario(usuario);
		login.setSenha(senha);
		boolean usuarioCadastrado = daoLogin.Cadastrar(login);
		response.getWriter().append("<html>"
				+ "<body>");
		if (usuarioCadastrado) {
			response.getWriter().append("Sucesso no cadastro");
		}else {
			response.getWriter().append("Falha no cadastro");
		}
		response.getWriter().append("<br />"
				+ "</body>"
				+ "</html>");
		doGet(request, response);
	}

}
