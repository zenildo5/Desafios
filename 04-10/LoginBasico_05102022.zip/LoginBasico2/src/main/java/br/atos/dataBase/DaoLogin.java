package br.atos.dataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
//import java.sql.ResultSet;
import java.sql.ResultSet;

import br.atos.model.Login;

public class DaoLogin {

	private ResultSet rs;

	public boolean Login(Login login) {
		boolean retorno = false;
		Connection conn = null;
		PreparedStatement pstm = null;

		try {

			String sql = "select * From funcionario.login where usuario = ? and senha = ?";
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, login.getUsuario());
			pstm.setString(2, login.getSenha());

			rs = pstm.executeQuery();
			retorno = rs.next();
			if (retorno) {
				System.out.println("Sucesso");
			} else {
				System.out.println("Falhou");
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar Logar.");
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}

		}
		return retorno;
	}

	public boolean Cadastrar(Login login) {

		boolean retorno = false;
		Connection conn = null;
		PreparedStatement pstm = null;

		try {

			String sql = "insert into funcionario.login(usuario,senha) values(?,?)";
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, login.getUsuario());
			pstm.setString(2, login.getSenha());

			retorno = pstm.executeUpdate() > 0;
			// retorno = rs.next();
			if (retorno) {
				System.out.println("Sucesso");
			} else {
				System.out.println("Falhou");
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar Logar.");
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}

		}
		return retorno;
	}
}
