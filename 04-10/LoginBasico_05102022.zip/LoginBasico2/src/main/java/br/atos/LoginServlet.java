package br.atos;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import br.atos.dataBase.DaoLogin;
import br.atos.model.Login;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String usuario = request.getParameter("textUsuario");
		String senha = request.getParameter("textSenha");
		
		DaoLogin daoLogin = new DaoLogin();
		Login login =  new Login();
		login.setUsuario(usuario);
		login.setSenha(senha);
		boolean usuarioLogado = daoLogin.Login(login);
		
		
	   if (usuarioLogado) {	
		   RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
		   
		   //Adicionando o nome do usário na sessão
		   HttpSession sessao = request.getSession();
		   sessao.setAttribute("nome", login.getUsuario());
			
		   //Enviando o request e o response para a pagina JSP
		   dispatcher.forward(request, response);
	   }else {
		   //Login falhou, chama a mesma página
		   doGet(request, response);
	   }
	
	}

}
