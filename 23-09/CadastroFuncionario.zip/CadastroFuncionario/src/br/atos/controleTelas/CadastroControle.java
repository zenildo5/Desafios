package br.atos.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Funcionario;
import br.atos.repositorio.FuncionarioRepositorio;
import br.atos.telas.Cadastro;
import br.atos.telas.MenuPrincipal;

public class CadastroControle implements ActionListener{

	private JTextField textFieldNome;
	private JTextField textFieldCpf;
	private JTextField textFieldSalario;
    private JFrame frameMenu;
    private JFrame frameCadastro;
	FuncionarioRepositorio funcionarioRepositorio = new FuncionarioRepositorio();
	
	
	public CadastroControle() {
		
	}
	public CadastroControle(JTextField textFieldNome, JTextField textFieldCpf, JTextField textFieldSalario, JFrame frameMenu,JFrame frameCadastro) {
		this.textFieldNome = textFieldNome;
		this.textFieldCpf = textFieldCpf;
		this.textFieldSalario = textFieldSalario;
		this.frameMenu = frameMenu;
		this.frameCadastro = frameCadastro;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Salvar");
		//e.paramString()
		
			
		Funcionario funcionario = new Funcionario();	
		
		funcionario.setNome(textFieldNome.getText());
		funcionario.setCpf(textFieldCpf.getText());
		funcionario.setSalario(Double.parseDouble(this.textFieldSalario.getText()));
		
		funcionarioRepositorio.inserirFuncionario(funcionario);
		
		this.frameMenu.setVisible(true);
		this.frameCadastro.setVisible(false);
		
	}

}
