package br.atos.repositorio;

import java.util.ArrayList;
import br.atos.model.Funcionario;

public class FuncionarioRepositorio implements InterfaceRepositorioFuncionario{
	
	static ArrayList<Funcionario> listaFuncionario = new ArrayList<>();
	
	@Override
	public void ExcluirFuncionario(String cpf) {
		Funcionario func = new Funcionario();
		
		for(Funcionario item : listaFuncionario) {
			if(item.getCpf().equals(cpf)) {
				func = item;
				break;
			}
		}
		listaFuncionario.remove(func);
	}

	@Override
	public boolean inserirFuncionario(Funcionario funcionario) {
		try {
			
			listaFuncionario.add(funcionario);
			System.out.println("Cadastrado");
			return true;
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	
	public ArrayList<Funcionario> ListarFuncionario() {
		return listaFuncionario;
	}
	
	public Funcionario ObterFuncionario(String cpf) {	
		Funcionario func = new Funcionario();
		
		for(Funcionario item : listaFuncionario) {
			if(item.getCpf().equals(cpf)) {
				func = item;
				break;
			}
		}
		return func;
	}

	public void Alterar(Funcionario funcionario) {
		this.ExcluirFuncionario(funcionario.getCpf());
		listaFuncionario.add(funcionario);
	}
}
