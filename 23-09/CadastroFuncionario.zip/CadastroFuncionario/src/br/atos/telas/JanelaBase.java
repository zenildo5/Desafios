package br.atos.telas;

public class JanelaBase {
	
}
