package br.atos.AcessoDados;

import java.sql.Connection;
import java.sql.PreparedStatement;
//import java.sql.ResultSet;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.atos.model.Endereco;
import br.atos.model.Professor;

public class ProfessorDao {
	Connection conn = null;
	PreparedStatement prst = null;

	public List<Professor> Obter() {


		List<Professor> professorLista = new ArrayList<>();
		Professor professor = new Professor();
		Endereco endereco = new Endereco();
		try {

			String sql = "select * From professor pr"
						+ "join pessoa pe"
						+ "on pe.idPessoa = pr.idPessoa"
						+ "join endereco en"
						+ "on en.idPessoa = pe.idPessoa";
			
			conn = FabricaConexao.cirarConexaoMySql();
			prst = conn.prepareStatement(sql);

			ResultSet rs = prst.executeQuery();
			while (rs.next()) {

				professor.setNome(rs.getString("nome"));
				professor.setCpf(sql);
				professor.setDisciplina(rs.getString("displina"));
				professor.setSalario(rs.getDouble("salario"));
				endereco.setCidade(rs.getString("cidade"));
				endereco.setRua(rs.getString("rua"));
				endereco.setCasa(rs.getInt("casa"));
				
				professor.setEndereco(endereco);
				
				professorLista.add(professor);
			}

			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
		
		return professorLista;
	}

	public void inserir(Professor professor) throws Exception {
		
		conn = FabricaConexao.cirarConexaoMySql();
		conn.setTransactionIsolation(0);
	
		String sqlPessoa = "insert into pessoa(nome,cpf) values(?,?)";
		prst = conn.prepareStatement(sqlPessoa);
		prst.setString(0, professor.getNome());
		prst.setString(1, professor.getCpf());
		prst.execute();
		
		String sqlIdPessoa = " select last_insert_id() as idPessoa";
		prst = conn.prepareStatement(sqlIdPessoa);
		ResultSet rs = prst.executeQuery();
		int idPessoa = rs.getInt("idPessoa");
		
		String sqlProfessor = "insert into professor(discipina,salario) values(?,?,?)";
		prst = conn.prepareStatement(sqlProfessor);
		prst.setString(0, professor.getDisciplina());
		prst.setDouble(1, professor.getSalario());
		prst.setInt(2, idPessoa);
		prst.execute();
		
		String sqlEndereco = "insert into endereco(cidade,rua,casa) values(?,?,?,?)";
		prst = conn.prepareStatement(sqlEndereco);
		prst.setString(0, professor.getEndereco().getCidade());
		prst.setString(1, professor.getEndereco().getRua());
		prst.setInt(2, professor.getEndereco().getCasa());
		prst.setInt(3, idPessoa);
		
		prst.execute();
		
		conn.commit();
	}

	public void alterar(Professor professor) {

	}

	public void excluir(Professor professor) {

	}
}
