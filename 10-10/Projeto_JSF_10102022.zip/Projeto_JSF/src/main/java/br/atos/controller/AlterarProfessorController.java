package br.atos.controller;



import javax.faces.bean.ManagedBean;

@ManagedBean(name = "alterarProfessor")
public class AlterarProfessorController {

	public String alterar() {
		return "cadastrarProfessor.xhtml";
	}
	
}
