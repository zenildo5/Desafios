package br.atos.controller;

import javax.faces.bean.ManagedBean;


@ManagedBean(name="alterarEstudante")
public class AlterarEstudanteController {
	
	public String alterar() {
		return "cadastrarEstudante.xhtml";
	}
}
