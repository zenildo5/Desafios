package br.atos.controller;

import javax.faces.bean.*;

@ManagedBean(name = "inicio")
public class InicioController {

	public String cadastrarProfessor() {
		return "cadastrarProfessor.xhtml";
	}
	
	public String cadastrarEstudante() {
		return "cadastrarEstudante.xhtml";
	}
}
