package br.atos.model;

public class Estudante extends Pessoa {

		private String turma;
		private double media;
		
		public String getTurma() {
			return turma;
		}
		public void setTurma(String turma) {
			this.turma = turma;
		}
		public double getMedia() {
			return media;
		}
		public void setMedia(double media) {
			this.media = media;
		}
		
}
