package br.atos.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import br.atos.model.Endereco;
import br.atos.model.Estudante;

@ManagedBean(name = "estudante")
@SessionScoped
public class EstudanteController {

	private Estudante estudante = new Estudante();
	private Endereco endereco = new Endereco();
	private List<Estudante> estudantes = new ArrayList<>();
	private Map<String,Object> sessionMap;
	
	public List<Estudante> getEstudantes() {
		estudante.setEndereco(endereco);
		return estudantes;
	}

	public void setEstudantes(List<Estudante> estudantes) {
		this.estudantes = estudantes;
	}

	

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public Estudante getEstudante() {
		return estudante;
	}

	public void setEstudante(Estudante estudante) {
		this.estudante = estudante;
	}
	
	public String cadastrarEstudante() {
		this.estudantes.add(estudante);
		limparEstudante();
		return "";
	}

	public String excluir(Estudante estudante) {
		this.estudantes.remove(estudante);		
		return "";
	}
	
	public String alterar(Estudante estudante) {
		this.sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		this.sessionMap.put("estudateAlterar", estudante);
		return "alterarEstudante.xhtml?faces-redirect=true";
	}
	private void limparEstudante() {
		this.estudante = new Estudante();
		this.endereco = new Endereco();
	}
	
	
}
