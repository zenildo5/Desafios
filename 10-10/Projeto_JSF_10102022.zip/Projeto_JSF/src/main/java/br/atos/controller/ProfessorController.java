package br.atos.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.*;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import br.atos.model.Endereco;
import br.atos.model.Professor;

@ManagedBean(name = "professor")
@SessionScoped
public class ProfessorController {

	private Professor professor = new Professor();
	private Endereco endereco  = new Endereco();
	private List<Professor> professores = new ArrayList<>();
	private Map<String, Object> sessionMap;
	
	public List<Professor> getProfessores() {
		/*if (this.professores.equals(null)) {
			professores = new ArrayList<>();
		}*/
		return professores;
	}
	
	public Professor getProfessor() {
		/*if (this.professor.equals(null)) {
			professor = new Professor();
			
		}*/
		
		professor.setEndereco(this.endereco);
		return professor;
	}

	public void setProfessores(List<Professor> professores) {
		this.professores = professores;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}


	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	public String cadastrarProfessor() {
		this.professores.add(professor);
		limparProfessor();
		return "";
	}

	private void limparProfessor() {
		this.professor = new Professor();
		this.endereco = new Endereco();
	}
	
	public String excluir(Professor professor) {
		this.professores.remove(professor);
		return "";
	}
	
	public String alterar(Professor professor) {
		/*int indice = this.professores.indexOf(professor);
		Professor p = this.professores.set(indice, professor);*/
		this.sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sessionMap.put("professorAlterar", professor);	
		return "alterarProfessor.xhtml?faces-redirect=true";
	}
	
}
