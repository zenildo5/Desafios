package br.atos.SitemaZoo.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.SitemaZoo.model.Cuidador;

public interface CuidadorRepository extends CrudRepository<Cuidador, Long>{
	Cuidador findById(long id);
}
