package br.atos.SitemaZoo.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="TB_Jaula")
public class Jaula implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idJaula;
	private String nomeZoologico;
	private String bloco;
	private int numeroJaula;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "TB_Cuidador_Jaula", 
	           joinColumns = { @JoinColumn(name = "idCuidador") }, inverseJoinColumns = {
			                   @JoinColumn(name = "idJaula") })
	private Set<Cuidador> cuidadorLista;

	//private Set<Animal> animalLista;	

	public long getIdJaula() {
		return idJaula;
	}
	public void setIdJaula(long id) {
		this.idJaula = id;
	}
	public String getNomeZoologico() {
		return nomeZoologico;
	}
	public void setNomeZoologico(String nomeZoologico) {
		this.nomeZoologico = nomeZoologico;
	}
	public String getBloco() {
		return bloco;
	}
	public void setBloco(String bloco) {
		this.bloco = bloco;
	}
	public int getNumeroJaula() {
		return numeroJaula;
	}
	public void setNumeroJaula(int numeroJaula) {
		this.numeroJaula = numeroJaula;
	}
	public Set<Cuidador> getCuidadorLista() {
		return cuidadorLista;
	}
	public void setCuidadorLista(Set<Cuidador> cuidadorLista) {
		this.cuidadorLista = cuidadorLista;
	}
	
	/*public Set<Animal> getAnimalLista() {
		return animalLista;
	}
	public void setAnimalLista(Set<Animal> animalLista) {
		this.animalLista = animalLista;
	}*/
	
}
