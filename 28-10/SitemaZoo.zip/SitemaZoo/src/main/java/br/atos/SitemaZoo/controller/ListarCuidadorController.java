package br.atos.SitemaZoo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.SitemaZoo.model.Cuidador;
import br.atos.SitemaZoo.repository.CuidadorRepository;

@Controller
public class ListarCuidadorController {
	
	@Autowired
	CuidadorRepository cuidadorRepository;
	private Iterable<Cuidador> cuidadorLista;
	
	@RequestMapping(value = "/listarCuidador", method = RequestMethod.GET)
	public ModelAndView listarCuidador() {		
		cuidadorLista = cuidadorRepository.findAll();
		ModelAndView modelAndView = new ModelAndView("listarCuidador");
		modelAndView.addObject("cuidadorLista", cuidadorLista);
		return modelAndView;
	}
	
	@RequestMapping(value = "excluirCuidador", method = RequestMethod.GET)
	public  String excluirCuidador(long id) {
		
		cuidadorRepository.deleteById(id);

		return "redirect:listarCuidador";
	}
	
	@RequestMapping(value = "obterCuidador", method = RequestMethod.GET)
	public  ModelAndView obterCuidador(long id) {
		
		Cuidador cuidador  = cuidadorRepository.findById(id);
		ModelAndView modelAndView = new ModelAndView("editarCuidador");
		modelAndView.addObject("cuidador", cuidador);
		return modelAndView;
	}
}
