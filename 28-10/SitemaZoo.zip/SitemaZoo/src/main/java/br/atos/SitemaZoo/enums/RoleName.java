package br.atos.SitemaZoo.enums;

public enum RoleName {
	
	ROLE_ADMIN,
	ROLE_USER;
}
