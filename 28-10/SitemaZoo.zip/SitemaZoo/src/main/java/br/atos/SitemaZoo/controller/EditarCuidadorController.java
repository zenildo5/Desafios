package br.atos.SitemaZoo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import br.atos.SitemaZoo.model.Cuidador;
import br.atos.SitemaZoo.repository.CuidadorRepository;

@Controller
public class EditarCuidadorController {

	@Autowired
	CuidadorRepository cuidadorRepository;
	
//	@RequestMapping(value = "/editarCuidador", method = RequestMethod.GET)
//	public String editarCuidador() {
//		return "/";
//	}
	
	@RequestMapping(value = "/salvarCuidador", method = RequestMethod.POST)
	public String salvarCuidador(Cuidador cuidador) {
		
		cuidadorRepository.save(cuidador);
		
		return "/editarCuidador";
	}
}
