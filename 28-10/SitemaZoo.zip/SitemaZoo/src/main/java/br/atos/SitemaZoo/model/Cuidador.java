package br.atos.SitemaZoo.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TB_Cuidador")
public class Cuidador implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idCuidador;
	public long getIdCuidador() {
		return idCuidador;
	}

	public void setIdCuidador(long idCuidador) {
		this.idCuidador = idCuidador;
	}

	public Set<Jaula> getJaulaLista() {
		return jaulaLista;
	}

	public void setJaulaLista(Set<Jaula> jaulaLista) {
		this.jaulaLista = jaulaLista;
	}

	private String matricula;
	private String nome;
    
	@ManyToMany(mappedBy = "cuidadorLista")
	private Set<Jaula> jaulaLista;

	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	/*
	 * public List<Jaula> getJaulaLista() { return jaulaLista; } public void
	 * setJaulaLista(List<Jaula> jaulaLista) { this.jaulaLista = jaulaLista; }
	 */
}
