package br.atos.repositorio;

import java.util.ArrayList;

import br.atos.model.Coordenador;

public interface InterfaceReporitorioCoordenador {

		public ArrayList<Coordenador> ListarCoordenador();
		public boolean ExcluirCoordenador(String cpf);
		public Coordenador ObterCoordenador(String cpf);
		boolean InserirCoordenador(Coordenador coordenador);
		public boolean Alterar(Coordenador coordenador);
	
}
