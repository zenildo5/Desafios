package br.atos.repositorio;

import java.util.ArrayList;

import br.atos.model.Coordenador;
import br.atos.persistencia.CoordenadorDAO;

public class CoordenadorRepositorio implements InterfaceReporitorioCoordenador {
	
	static ArrayList<Coordenador> listaCoordenador = new ArrayList<>();
	
	@Override
	public ArrayList<Coordenador> ListarCoordenador() {
		CoordenadorDAO coordenadorDAO = new CoordenadorDAO();
		return coordenadorDAO.Listar();
	}

	@Override
	public boolean ExcluirCoordenador(String cpf) {
		CoordenadorDAO coordenadorDAO = new CoordenadorDAO();
		return coordenadorDAO.Excluir(cpf);		
	}

	@Override
	public Coordenador ObterCoordenador(String cpf) {
		CoordenadorDAO coordenadorDAO = new CoordenadorDAO();
		return coordenadorDAO.ObterCoordenador(cpf);
	}

	@Override
	public boolean InserirCoordenador(Coordenador coordenador) {
		try {
			
			CoordenadorDAO dao=new CoordenadorDAO();
			dao.Incluir(coordenador);
			listaCoordenador.add(coordenador);
			System.out.println("Cadastrado");
			return true;
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean Alterar(Coordenador coordenador) {
		CoordenadorDAO coordenadorDAO = new CoordenadorDAO();
		return coordenadorDAO.Alterar(coordenador);
	}



}
