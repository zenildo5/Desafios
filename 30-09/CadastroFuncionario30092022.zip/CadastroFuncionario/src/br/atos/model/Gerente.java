package br.atos.model;

public class Gerente extends Funcionario{
	private String regional;
	private Double metaRegional;
	
	public Double getMetaRegional() {
		return metaRegional;
	}
	public void setMetaRegional(Double metaRegional) {
		this.metaRegional = metaRegional;
	}
	public String getRegional() {
		return regional;
	}
	public void setRegional(String regional) {
		this.regional = regional;
	}
	@Override
	protected Double calcularSalario(Integer qtdHoras) {
		return (60 * qtdHoras) * 0.85;
	}
}
