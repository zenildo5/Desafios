package br.atos.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import br.atos.model.Coordenador;

public class CoordenadorDAO {
	
	public boolean Incluir(Coordenador coordenador) {
		String sql = "INSERT INTO funcionario.coordenador (cpf, nome, salario, loja, metaLoja) VALUES( ?,?,?,?,?)";
		boolean retorno  =false;
		
		Connection conn = null;
		PreparedStatement pstm = null;
				
		try {
			
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, coordenador.getCpf());
			pstm.setString(2, coordenador.getNome());
			pstm.setDouble(3, coordenador.getSalario());
			pstm.setString(4, coordenador.getLoja());
			pstm.setDouble(5, coordenador.getMetaloja());
			
			pstm.execute();
			
			System.out.println("Incluido com sucesso.");
			
			retorno = true;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar inserir.");
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}
			
		}
		return retorno;
	}
	
	public ArrayList<Coordenador> Listar(){
		String sql = "select * From funcionario.coordenador order by nome";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		ArrayList<Coordenador> listaRetorno = new ArrayList<>();
		
		try {
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			
			ResultSet rs = pstm.executeQuery();
			
			while (rs.next()) {
				Coordenador coordenador = new Coordenador();
				coordenador.setCpf(rs.getNString("cpf"));
				coordenador.setNome(rs.getNString("nome"));
				coordenador.setSalario(rs.getDouble("salario"));
				coordenador.setLoja(rs.getNString("loja"));
				coordenador.setMetaloja(rs.getDouble("metaLoja"));
				listaRetorno.add(coordenador);
			}
			
			return listaRetorno;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao Listar.");
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}
		}
		return listaRetorno;
	}
	
	public boolean Excluir(String cpf) {
		String sql = "delete from funcionario.coordenador where cpf = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		boolean retorno = false; 
		
		try {
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareCall(sql);
			pstm.setString(1, cpf);
			pstm.execute();
			retorno = true;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar inserir.");
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}
		
		}
		return retorno;
	}
		
	public boolean Alterar(Coordenador coordenador) {
		String sql = "update funcionario.coordenador "
				   + "set "
				   + "    nome=?,"
				   + "    salario=?,"
				   + "    loja =?,"
				   + "    metaLoja=? "
				   + "where cpf=?";
		
		boolean retorno  =false;
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, coordenador.getNome());
			pstm.setDouble(2, coordenador.getSalario());
			pstm.setString(3, coordenador.getLoja());
			pstm.setDouble(4, coordenador.getMetaloja());
			pstm.setString(5, coordenador.getCpf());
			
			pstm.execute();
			
			System.out.println("Incluido com sucesso.");
			retorno = true;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar inserir.");
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}
			
		}
		return retorno;
		
	}

	public Coordenador ObterCoordenador(String cpf){
		String sql = "select * From funcionario.coordenador where cpf = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		Coordenador coordenador = new Coordenador();
		
		try {
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, cpf);
			ResultSet rs = pstm.executeQuery();
			while(rs.next()) {
				coordenador.setCpf(rs.getNString("cpf"));
				coordenador.setNome(rs.getNString("nome"));
				coordenador.setSalario(rs.getDouble("salario"));
				coordenador.setLoja(rs.getNString("loja"));
				coordenador.setMetaloja(rs.getDouble("metaLoja"));						
			}
			return coordenador;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao Listar.");
		}finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}
		}
		return coordenador;
	}

}
