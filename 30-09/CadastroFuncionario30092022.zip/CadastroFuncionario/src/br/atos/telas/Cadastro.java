package br.atos.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.atos.controleTelas.CadastroControle;

public class Cadastro {

	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	JFrame jframeMenu;
	
	
	public Cadastro(JFrame jframeMenu) {
		
		this.jframeMenu = jframeMenu;
	}
	public void ExibirTela() {
		frame.setSize(160, 320);
		frame.setTitle("Cadadtro");
		frame.setLocation(400, 400);
		
		
		frame.add(panel);
		
		JLabel labelNome = new JLabel("Nome");		
		JTextField textNome = new JTextField(12);
		panel.add(labelNome);
		panel.add(textNome);
		
		JLabel labelCpf = new JLabel("Cpf ");
		JTextField textCpf = new JTextField(12);
		panel.add(labelCpf);
		panel.add(textCpf);
		
		JLabel labelSalario = new JLabel("Salario ");
		JTextField textSalario = new JTextField(12);
		panel.add(labelSalario);				
		panel.add(textSalario);
		
		JLabel labelLoja = new JLabel("Loja ");
		JTextField textFieldLoja = new JTextField(12);
		panel.add(labelLoja);				
		panel.add(textFieldLoja);
		
		JLabel labelMeta = new JLabel("Meta Loja ");
		JTextField textFieldMeta = new JTextField(12);
		panel.add(labelMeta);				
		panel.add(textFieldMeta);
		
		JButton botaoSalvar = new JButton("Salvar");
		panel.add(botaoSalvar);
		
		CadastroControle cadastroControle = new CadastroControle(textNome,textCpf,textSalario,textFieldLoja, textFieldMeta, jframeMenu,frame);
		botaoSalvar.addActionListener(cadastroControle);
		
		frame.setVisible(true);
	}
}
