package br.atos.telas;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import br.atos.controleTelas.ListaControle;
import br.atos.model.Coordenador;

public class Listar {
	JFrame frameTela = new JFrame();
	/*JPanel panelTela = new JPanel();*/
	JFrame frameMenu;
	
	public Listar(JFrame frameMenu) {
		this.frameMenu = frameMenu;
	}

	public void ExibirTela() {


	
		JTextField textFieldAlteracao = new JTextField(20);	
		
		ListaControle listaControle = new ListaControle(textFieldAlteracao,frameTela,frameMenu);
		
		ArrayList<Coordenador> lista = listaControle.ListarCoordenador();
		
		Integer qtdLinhas = lista.size();
		
		String [][] linhas = new String[qtdLinhas][5];
		int posicaoLinha = 0;
		int posicaoColuna = 0;
		
		for(Coordenador item: lista) {
			linhas[posicaoLinha][posicaoColuna] = item.getNome();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = item.getCpf();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = String.valueOf(item.getSalario());
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = item.getLoja();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = String.valueOf(item.getMetaloja());
			posicaoColuna = 0;
			posicaoLinha++;
		}
		
		String[] colunas = {"Nome", "CPF", "Salario", "Loja", "Meta_Loja"};
		
		//JFrame frameLista = new JFrame();	
		
		frameTela.setSize(500, 600);
		
		JTable tabelaGrid = new JTable(linhas, colunas);
		tabelaGrid.setBounds(30,40,200,300);
		
		JScrollPane scrollTable = new JScrollPane(tabelaGrid);
		
		JPanel panelTela = new JPanel();
		panelTela.add(scrollTable);
		frameTela.add(panelTela);
		frameTela.setVisible(true);
		
		/*String[] colunasTitulo = {"Nome", "CPF", "Salario", "Loja", "Meta_Loja"};
		JTable tabelaGrid = new JTable(linhas,colunasTitulo);
		
		JScrollPane scrollTable = new JScrollPane(tabelaGrid);
		scrollTable.setBounds(30,40,200,300);
		
		JPanel panelTela = new JPanel();
		
		
		panelTela.add(scrollTable);
		panelTela.add(tabelaGrid);
		*/
		JButton buttonExcluir = new JButton("Excluir");
		JButton buttonAlterar = new JButton("Alterar");
		buttonExcluir.addActionListener(listaControle);
		buttonAlterar.addActionListener(listaControle);
		JLabel labelAlteracao = new JLabel("CPF ");
		panelTela.add(labelAlteracao);
		panelTela.add(textFieldAlteracao);
		panelTela.add(buttonAlterar);
		panelTela.add(buttonExcluir);
		
		JButton buttonVoltar = new JButton("Voltar");
		buttonVoltar.addActionListener(listaControle);
		panelTela.add(buttonVoltar);
		/*frameTela.add(panelTela);
		frameTela.setVisible(true);*/
		
	}
}
