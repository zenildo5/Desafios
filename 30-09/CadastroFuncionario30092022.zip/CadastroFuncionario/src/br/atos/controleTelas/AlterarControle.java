package br.atos.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Coordenador;
import br.atos.repositorio.CoordenadorRepositorio;

public class AlterarControle implements ActionListener  {

	JFrame frameMenu;
	JFrame frameAlterar;
	JTextField textFieldNome; 
	JTextField textFieldSalario;
	JTextField textFieldCpf;
	JTextField textFieldLoja;
	JTextField textFieldMetaLoja;
	
	public AlterarControle(JFrame frameMenu, JFrame frameAlterar, JTextField textFieldNome, JTextField textFieldCpf, JTextField textFieldSalario, JTextField textFieldLoja, JTextField textFieldMetaLoja) {
		this.frameAlterar = frameAlterar;
		this.frameMenu = frameMenu;
		this.textFieldNome = textFieldNome;
		this.textFieldCpf = textFieldCpf;
		this.textFieldSalario = textFieldSalario;
		this.textFieldLoja = textFieldLoja;
		this.textFieldMetaLoja = textFieldMetaLoja;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		CoordenadorRepositorio repositorio = new CoordenadorRepositorio();
		
		Coordenador coordenador = new Coordenador();
		coordenador.setNome(textFieldNome.getText());
		coordenador.setCpf(textFieldCpf.getText());
		coordenador.setSalario(Double.parseDouble(textFieldSalario.getText()));
		coordenador.setLoja(textFieldLoja.getText());
		coordenador.setMetaloja(Double.parseDouble(textFieldMetaLoja.getText()));
		
		repositorio.Alterar(coordenador);
		
		frameAlterar.setVisible(false);
		frameMenu.setVisible(true);
		
	}

}
