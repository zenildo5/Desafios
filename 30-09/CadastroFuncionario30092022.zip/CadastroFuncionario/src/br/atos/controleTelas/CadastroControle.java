package br.atos.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Coordenador;
import br.atos.repositorio.CoordenadorRepositorio;
import br.atos.telas.Cadastro;
import br.atos.telas.MenuPrincipal;

public class CadastroControle implements ActionListener{

	private JTextField textFieldNome;
	private JTextField textFieldCpf;
	private JTextField textFieldSalario;
    private JFrame frameMenu;
    private JFrame frameCadastro;
    private JTextField textFieldLoja;
    private JTextField textFieldMetaLoja;
	CoordenadorRepositorio coordenadorRepositorio = new CoordenadorRepositorio();
	
	
	public CadastroControle() {
		
	}
	public CadastroControle(JTextField textFieldNome, JTextField textFieldCpf, JTextField textFieldSalario,JTextField textFieldLoja, JTextField textFieldMetaLoja, JFrame frameMenu,JFrame frameCadastro) {
		this.textFieldNome = textFieldNome;
		this.textFieldCpf = textFieldCpf;
		this.textFieldSalario = textFieldSalario;
		this.frameMenu = frameMenu;
		this.frameCadastro = frameCadastro;
		this.textFieldLoja = textFieldLoja;
		this.textFieldMetaLoja = textFieldMetaLoja;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Salvar");
		//e.paramString()
		
			
		Coordenador coordenador = new Coordenador();	
		
		coordenador.setNome(textFieldNome.getText());
		coordenador.setCpf(textFieldCpf.getText());
		coordenador.setSalario(Double.parseDouble(this.textFieldSalario.getText()));
		coordenador.setLoja(this.textFieldLoja.getText());
		coordenador.setMetaloja(Double.valueOf(this.textFieldMetaLoja.getText()));
		
		coordenadorRepositorio.InserirCoordenador(coordenador);
		
		this.frameMenu.setVisible(true);
		this.frameCadastro.setVisible(false);
		
	}

}
