package br.atos.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Coordenador;
import br.atos.repositorio.CoordenadorRepositorio;
import br.atos.telas.Alterar;

public class ListaControle implements ActionListener {
	
	private JTextField textFieldAlterar;
	private JFrame frameMenu;
	private JFrame frameLista;
	
	public ListaControle() {
		
	}
	public ListaControle(JTextField textFieldAlterar, JFrame frameLista, JFrame frameMenu) {
		this.textFieldAlterar = textFieldAlterar;
		this.frameMenu = frameMenu;
		this.frameLista = frameLista;
	}
	public ArrayList<Coordenador> ListarCoordenador(){
	  return new CoordenadorRepositorio().ListarCoordenador();
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton botao = ((JButton) e.getSource());
		if (botao.getText() == "Excluir") {
					
			CoordenadorRepositorio repositorio = new CoordenadorRepositorio();
			boolean sucesso = repositorio.ExcluirCoordenador(this.textFieldAlterar.getText());
			if (sucesso) {
				frameLista.setVisible(false);
				frameMenu.setVisible(true);
				System.out.println("Excluido com sucesso.");
				System.out.println(this.textFieldAlterar.getText());
			}else {
				System.out.println("Erro ao Excluir");
				System.out.println(this.textFieldAlterar.getText());
			}
			
		}
		else if(botao.getText() == "Alterar") {
			CoordenadorRepositorio coordenadorRepositorio = new CoordenadorRepositorio();
			Coordenador coordenador = coordenadorRepositorio.ObterCoordenador(this.textFieldAlterar.getText());
			frameLista.setVisible(false);
			frameMenu.setVisible(false);
			Alterar alterar = new Alterar(frameMenu);
			alterar.ExibirTela(coordenador);
			boolean sucesso = coordenadorRepositorio.Alterar(coordenador);
			if (sucesso) {
			    System.out.println("Alterado com sucesso");
				System.out.println(this.textFieldAlterar.getText());
			}else {
			    System.out.println("Erro ao Alterar");
				System.out.println(this.textFieldAlterar.getText());
			}

		}else if(botao.getText() == "Voltar") {
			frameLista.setVisible(false);
			frameMenu.setVisible(true);
		}
	}
}
