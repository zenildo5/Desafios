package br.atos;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class ServletInicio
 */
public class ServletInicio extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletInicio() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String html = "<html>"
					+ "<head>"
						+ "<title>Dados do Aluno</title>"
					+ "</head>"
					+ "<body>"
						+ "<h1>Dados do Aluno</h1>"
						+ "<p>Nome: Zenildo</P>"
						+ "<p>Idade: 43</P>"
						+ "<p>E-mail: zenildo5@yahoo.com.br</P>"
						+ "<h3>Em 5 anos espero ser um analista Java pleno.</h3>"
					+ "</body>"
				+ "</html>";
		response.getWriter().append(html);//.append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
