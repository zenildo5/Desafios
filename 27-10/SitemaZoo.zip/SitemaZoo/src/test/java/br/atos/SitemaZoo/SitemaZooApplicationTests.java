package br.atos.SitemaZoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SitemaZooApplicationTests {

	@Test
	void contextLoads() {
	}

}
