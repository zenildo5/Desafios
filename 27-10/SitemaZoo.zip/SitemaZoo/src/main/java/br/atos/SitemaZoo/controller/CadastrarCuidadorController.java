package br.atos.SitemaZoo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.SitemaZoo.model.Cuidador;
import br.atos.SitemaZoo.repository.CuidadorRepository;

@Controller
public class CadastrarCuidadorController {

	@Autowired
	CuidadorRepository cuidadorRepository;

	@RequestMapping(value = "/cadastrarCuidador")
	public String cadastrarCuidador() {
		/*ModelAndView modelAndView = new ModelAndView("cadastrarCuidador");
		Iterable<Cuidador> cuidadorLista = cuidadorRepository.findAll();
		modelAndView.addObject("cuidadorLista", cuidadorLista);*/
		return "cadastrarCuidador";
	}

	@RequestMapping(value = "cadastrarCuidador", method = RequestMethod.POST)
	public ModelAndView cadastrarCuidador(Cuidador cuidador) {

		cuidadorRepository.save(cuidador);

		ModelAndView modelAndView = new ModelAndView("cadastrarCuidador");

		Iterable<Cuidador> cuidadorLista = cuidadorRepository.findAll();
		modelAndView.addObject("cuidadorLista", cuidadorLista);
		return modelAndView;
	}
	
	@RequestMapping(value = "/obterCuidador", method = RequestMethod.GET)
	public ModelAndView obterCuidador(Long idCuidador) {
			
		ModelAndView modelAndView = new ModelAndView("cadastrarCuidador");

		Iterable<Cuidador> cuidadorLista = cuidadorRepository.findAll();
		modelAndView.addObject("cuidadorLista", cuidadorLista);
		
		Optional<Cuidador> cuidador = cuidadorRepository.findById(idCuidador);
		modelAndView.addObject("cuidadorEditar", cuidador);
		
		return modelAndView;
	}
	
	/*public ModelAndView editarCuidador(Cuidador cuidador) {
		
		ModelAndView modelAndView = new ModelAndView("cadastrarCuidador");
		modelAndView.a
	}*/
}
