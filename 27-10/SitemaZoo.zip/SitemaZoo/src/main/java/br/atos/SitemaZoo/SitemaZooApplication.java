package br.atos.SitemaZoo;

import java.util.UUID;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class SitemaZooApplication {

	public static void main(String[] args) {
		SpringApplication.run(SitemaZooApplication.class, args);
		
		System.out.println(new BCryptPasswordEncoder().encode("Senha"));
		System.out.println(UUID.randomUUID());
	}

}
