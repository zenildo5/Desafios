package br.atos.SitemaZoo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.SitemaZoo.model.Cuidador;
import br.atos.SitemaZoo.repository.CuidadorRepository;

@Controller
public class ListarCuidadorController {
	
	@Autowired
	CuidadorRepository cuidadorRepository;
	private Iterable<Cuidador> cuidadorLista;
	
	@RequestMapping(value = "/listarCuidador", method = RequestMethod.GET)
	public ModelAndView listarCuidador() {		
		cuidadorLista = cuidadorRepository.findAll();
		ModelAndView modelAndView = new ModelAndView("listarCuidador");
		modelAndView.addObject("cuidadorLista", cuidadorLista);
		return modelAndView;
	}
}
