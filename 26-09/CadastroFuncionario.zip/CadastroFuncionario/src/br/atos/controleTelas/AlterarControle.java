package br.atos.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Funcionario;
import br.atos.repositorio.FuncionarioRepositorio;

public class AlterarControle implements ActionListener  {

	JFrame frameMenu;
	JFrame frameAlterar;
	JTextField textFieldNome; 
	JTextField textFieldSalario;
	JTextField textFieldCpf;
	
	public AlterarControle(JFrame frameMenu, JFrame frameAlterar, JTextField textFieldNome, JTextField textFieldCpf, JTextField textFieldSalario ) {
		this.frameAlterar = frameAlterar;
		this.frameMenu = frameMenu;
		this.textFieldNome = textFieldNome;
		this.textFieldCpf = textFieldCpf;
		this.textFieldSalario = textFieldSalario;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		FuncionarioRepositorio repositorio = new FuncionarioRepositorio();
		
		Funcionario funcionario = new Funcionario();
		funcionario.setNome(textFieldNome.getText());
		funcionario.setCpf(textFieldCpf.getText());
		funcionario.setSalario(Double.parseDouble(textFieldSalario.getText()));
		
		repositorio.Alterar(funcionario);
		
		frameAlterar.setVisible(false);
		frameMenu.setVisible(true);
		
	}

}
