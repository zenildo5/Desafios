package br.atos.controleTelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import br.atos.model.Funcionario;
import br.atos.repositorio.FuncionarioRepositorio;
import br.atos.telas.Alterar;

public class ListaControle implements ActionListener {
	
	private JTextField textFieldAlterar;
	private JFrame frameMenu;
	private JFrame frameLista;
	
	public ListaControle() {
		
	}
	public ListaControle(JTextField textFieldAlterar, JFrame frameLista, JFrame frameMenu) {
		this.textFieldAlterar = textFieldAlterar;
		this.frameMenu = frameMenu;
		this.frameLista = frameLista;
	}
	public ArrayList<Funcionario> ListarFuncionario(){
	  return new FuncionarioRepositorio().ListarFuncionario();
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton botao = ((JButton) e.getSource());
		if (botao.getText() == "Excluir") {
					
			FuncionarioRepositorio repositorio = new FuncionarioRepositorio();
			repositorio.ExcluirFuncionario(this.textFieldAlterar.getText());
			frameLista.setVisible(false);
			frameMenu.setVisible(true);
			System.out.println("Excluir");
			System.out.println(this.textFieldAlterar.getText());
		}
		else if(botao.getText() == "Alterar") {
			FuncionarioRepositorio funcionarioRepositorio = new FuncionarioRepositorio();
			Funcionario funcionario = funcionarioRepositorio.ObterFuncionario(this.textFieldAlterar.getText());
			frameLista.setVisible(false);
			frameMenu.setVisible(false);
			Alterar alterar = new Alterar(frameMenu);
			alterar.ExibirTela(funcionario);
			funcionarioRepositorio.Alterar(funcionario);
			System.out.println("Alterar");
			System.out.println(this.textFieldAlterar.getText());
		}
	}
}
