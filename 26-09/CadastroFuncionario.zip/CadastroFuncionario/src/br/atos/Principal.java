package br.atos;

import br.atos.contraldor.RegistroControlador;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RegistroControlador registroControlador = new RegistroControlador();
		registroControlador.IniciarPrograma();
	}

}
