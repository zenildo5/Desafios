package br.atos.repositorio;

import java.util.ArrayList;

import br.atos.model.Funcionario;

public interface InterfaceRepositorioFuncionario {

	public boolean inserirFuncionario(Funcionario funcionario);
	public ArrayList<Funcionario> ListarFuncionario();
	public void ExcluirFuncionario(String cpf);
	public Funcionario ObterFuncionario(String cpf);
}
