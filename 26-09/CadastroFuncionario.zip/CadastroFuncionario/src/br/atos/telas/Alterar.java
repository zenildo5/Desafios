package br.atos.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.atos.controleTelas.AlterarControle;
import br.atos.model.Funcionario;
import br.atos.repositorio.FuncionarioRepositorio;

public class Alterar {
	

	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	JFrame frameMenu = new JFrame();
	
	public Alterar(JFrame frameMenu) {
		this.frameMenu = frameMenu;
	}
	
	public void ExibirTela(Funcionario funcionario) {
		frame.setSize(220, 200);
		frame.setTitle("Cadadtro");
		frame.setLocation(400, 400);
				
		frame.add(panel);
		
		JLabel labelNome = new JLabel("Nome");		
		JTextField textFieldNome = new JTextField(funcionario.getNome(),10);
		panel.add(labelNome);
		panel.add(textFieldNome);
		
		JLabel labelCpf = new JLabel("Cpf ");
		JTextField textFieldCpf = new JTextField(funcionario.getCpf(),10);
		textFieldCpf.enable(false);
		panel.add(labelCpf);
		panel.add(textFieldCpf);
		
		JLabel labelSalario = new JLabel("Salario ");
		JTextField textFieldSalario = new JTextField(funcionario.getSalario().toString(),10);
		panel.add(labelSalario);				
		panel.add(textFieldSalario);
		
		JButton botaoSalvar = new JButton("Salvar");
		panel.add(botaoSalvar);
		
    
		AlterarControle cadastroControle = new AlterarControle(frameMenu,frame,textFieldNome,textFieldCpf, textFieldSalario);
		botaoSalvar.addActionListener(cadastroControle);
		
		frame.setVisible(true);
	}
}
