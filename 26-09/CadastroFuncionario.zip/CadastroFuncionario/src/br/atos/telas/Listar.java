package br.atos.telas;

import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import br.atos.controleTelas.ListaControle;
import br.atos.model.Funcionario;

public class Listar {
	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	JFrame frameMenu;
	
	public Listar(JFrame frameMenu) {
		this.frameMenu = frameMenu;
	}

	public void ExibirTela() {
		this.frame.setSize(270, 500);
		frame.add(panel);
		JLabel labelExcluir = new JLabel("CPF ");
		JTextField textFieldAlteracao = new JTextField(20);		
		
		
		ListaControle listaControle = new ListaControle(textFieldAlteracao,frame,frameMenu);
		
		ArrayList<Funcionario> lista = listaControle.ListarFuncionario();
			
		String [] colunas= {"Nome","CPF","Salario"};
		
		String [][] linhas = new String[lista.size()][3];
		int posicaoLinha = 0;
		int posicaoColuna = 0;
		
		for(Funcionario item: lista) {
			linhas[posicaoLinha][posicaoColuna] = item.getNome();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = item.getCpf();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = item.getSalario().toString();
			posicaoColuna = 0;
			posicaoLinha++;
		}
		
		JTable tabela = new JTable(linhas,colunas);
		JScrollPane scroll = new JScrollPane(tabela);
		tabela.setBounds(30,40,200,300);
		panel.add(scroll);
		panel.add(tabela);
		
		JButton buttonExcluir = new JButton("Excluir");
		JButton buttonAlterar = new JButton("Alterar");
		buttonExcluir.addActionListener(listaControle);
		buttonAlterar.addActionListener(listaControle);
		panel.add(labelExcluir);
		panel.add(textFieldAlteracao);
		panel.add(buttonExcluir);
		panel.add(buttonAlterar);
		
		frame.setVisible(true);
		
	}
}
