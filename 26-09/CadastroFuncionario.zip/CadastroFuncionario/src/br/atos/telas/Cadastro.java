package br.atos.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.atos.controleTelas.CadastroControle;

public class Cadastro {

	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	
	
	public Cadastro(JFrame jframeMenu) {
		
		frame.setSize(180, 220);
		frame.setTitle("Cadadtro");
		frame.setLocation(400, 400);
		
		
		frame.add(panel);
		
		JLabel labelNome = new JLabel("Nome");		
		JTextField textNome = new JTextField(12);
		panel.add(labelNome);
		panel.add(textNome);
		
		JLabel labelCpf = new JLabel("Cpf ");
		JTextField textCpf = new JTextField(12);
		panel.add(labelCpf);
		panel.add(textCpf);
		
		JLabel labelSalario = new JLabel("Salario ");
		JTextField textSalario = new JTextField(12);
		panel.add(labelSalario);				
		panel.add(textSalario);
		
		JButton botaoSalvar = new JButton("Salvar");
		panel.add(botaoSalvar);
		
		CadastroControle cadastroControle = new CadastroControle(textNome,textCpf,textSalario, jframeMenu,frame);
		botaoSalvar.addActionListener(cadastroControle);
		
		frame.setVisible(true);
	}
	
}
