package br.atos.controlador;

public class ControleCadastro {

}
