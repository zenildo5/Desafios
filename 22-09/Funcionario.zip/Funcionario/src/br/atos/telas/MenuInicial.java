package br.atos.telas;

import javax.swing.JFrame;

public class MenuInicial {
	public void ExibirTela() {
		JFrame  frame = new JFrame();
		
		
	}
}
