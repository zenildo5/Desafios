package br.atos.SitemaZoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SitemaZooApplication {

	public static void main(String[] args) {
		SpringApplication.run(SitemaZooApplication.class, args);
	}

}
