package br.atos.Petshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
