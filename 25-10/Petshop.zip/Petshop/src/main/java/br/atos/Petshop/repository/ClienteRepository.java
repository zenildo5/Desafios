package br.atos.Petshop.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.Petshop.model.Cliente;

public interface ClienteRepository extends CrudRepository<Cliente, Long>{
	Cliente findById(long id);
	
}
