package br.atos.Petshop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.Petshop.model.*;
import br.atos.Petshop.repository.ClienteRepository;

@Controller
public class ClienteController {

	@Autowired
	ClienteRepository clienteRepository;

	@RequestMapping(value = "/cadastroCliente", method = RequestMethod.GET)
	public String cadastroCliente() {

		return "cadastroCliente";
	}

	@RequestMapping(value = "/cadastroCliente", method = RequestMethod.POST)
	public String cadastrarCliente(Cliente cliente) {

		clienteRepository.save(cliente);
		return "cadastroCliente";
	}

	@RequestMapping(value = "/listaCliente", method = RequestMethod.GET)
	public ModelAndView listaCliente() {

		ModelAndView modelAndView = new ModelAndView("listaCliente");
		Iterable<Cliente> listaCliente = clienteRepository.findAll();
		modelAndView.addObject("listaCliente", listaCliente);
		return modelAndView;
	}

	@RequestMapping(value = "/excluirCliente/{id}", method = RequestMethod.GET)
	public String excluirCliente(@PathVariable("id") long idRequisicao) {

		clienteRepository.deleteById(idRequisicao);

		return "redirect:/listaCliente";

	}

	@RequestMapping(value = "/obterCliente/{id}", method = RequestMethod.GET)
	public ModelAndView obterCliente(@PathVariable("id") long idRequisicao) {
		ModelAndView modelAndView = new ModelAndView("editarCliente.html");
		Cliente cliente = clienteRepository.findById(idRequisicao);
		modelAndView.addObject("cliente", cliente);
		return modelAndView;
	}

	@RequestMapping(value = "/editarCliente", method = RequestMethod.POST)
	public String editarCliente(Cliente cliente) {
		clienteRepository.save(cliente);
		return "redirect:/listaCliente";
	}
}
