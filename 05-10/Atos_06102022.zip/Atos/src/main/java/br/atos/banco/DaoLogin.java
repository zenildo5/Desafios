package br.atos.banco;

import java.sql.Connection;
import java.sql.PreparedStatement;
//import java.sql.ResultSet;
import java.sql.ResultSet;

import br.atos.model.Usuario;

public class DaoLogin {

	private ResultSet rs;

	public boolean Login(Usuario usuario) {
		boolean retorno = false;
		Connection conn = null;
		PreparedStatement pstm = null;

		try {

			String sql = "select * From funcionario.usuario where usuario = ? and senha = ?";
			
			conn = FabricaConexao.cirarConexaoMySql();
			
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, usuario.getUsuario());
			pstm.setString(2, usuario.getSenha());

			rs = pstm.executeQuery();
			retorno = rs.next();
			if (retorno) {
				System.out.println("Sucesso");
			} else {
				System.out.println("Falhou");
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar Logar.");
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}

		}
		return retorno;
	}

	public boolean Registrar(Usuario usuario) {

		boolean retorno = false;
		Connection conn = null;
		PreparedStatement pstm = null;

		try {

			String sql = "insert into funcionario.usuario(usuario,senha,email,telefone) values(?,?,?,?)";
			conn = FabricaConexao.cirarConexaoMySql();
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, usuario.getUsuario());
			pstm.setString(2, usuario.getSenha());
			pstm.setString(3, usuario.getEmail());
			pstm.setString(4, usuario.getTelefone());

			retorno = pstm.executeUpdate() > 0;
			// retorno = rs.next();
			if (retorno) {
				System.out.println("Sucesso");
			} else {
				System.out.println("Falhou");
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar Logar.");
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				System.out.print("Erro ao tentar fechar a conexao");
			}

		}
		return retorno;
	}
}
