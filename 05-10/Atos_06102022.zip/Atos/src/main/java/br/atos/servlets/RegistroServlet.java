package br.atos.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import br.atos.banco.DaoLogin;
import br.atos.model.Usuario;

/**
 * Servlet implementation class RegistroServlet
 */
@WebServlet("/registrar")
public class RegistroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistroServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DaoLogin daoLogin = new DaoLogin();
		Usuario usuario = new Usuario();
		
		usuario.setUsuario(request.getParameter("name"));
		usuario.setSenha(request.getParameter("pass"));
		usuario.setEmail(request.getParameter("email"));
		usuario.setTelefone(request.getParameter("contact"));
		
		boolean registrado = daoLogin.Registrar(usuario);
		
		if (registrado) {
			response.sendRedirect("login.jsp");
		}else {
			System.out.println("não registrado");
		}
			
		
		
		
	}

}
