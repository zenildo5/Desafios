package br.atos.cadastro_progamadores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroProgamadoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
