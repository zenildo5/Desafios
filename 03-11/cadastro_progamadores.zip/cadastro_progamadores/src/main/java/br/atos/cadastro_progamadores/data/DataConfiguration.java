package br.atos.cadastro_progamadores.data;


import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

@Configuration
public class DataConfiguration {

	/*@Bean
	public DataSource dataSource() {
		DriverManagerDataSource driveBanco = new DriverManagerDataSource();
		driveBanco.setDriverClassName("org.postgresql.Driver");
		driveBanco.setUrl("jdbc:postgresql://udd08fildztifxzj4zpg:ul2VkAFJDkELF8p0LItP@bgr24t7h7gxpd8c5qzaq-postgresql.services.clever-cloud.com:5432/bgr24t7h7gxpd8c5qzaq");
		driveBanco.setUsername("udd08fildztifxzj4zpg");
		driveBanco.setPassword("ul2VkAFJDkELF8p0LItP");
		return driveBanco;
	}
	@Bean
	public JpaVendorAdapter jpaVendorAdapter() {
		HibernateJpaVendorAdapter adapter = new HibernateJpaVendorAdapter();
		adapter.setDatabase(Database.POSTGRESQL);
		adapter.setShowSql(true);
		adapter.setGenerateDdl(true);
		adapter.setDatabasePlatform("org.hibernate.dialect.PostgreSQLDialect");
		adapter.setPrepareConnection(true);
		return adapter;
	}*/
	
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource driveBanco = new DriverManagerDataSource();
		driveBanco.setDriverClassName("com.mysql.cj.jdbc.Driver");
		driveBanco.setUrl("jdbc:mysql://bqg8vlwarjtvgmtreq9b-mysql.services.clever-cloud.com:3306/bqg8vlwarjtvgmtreq9b");
		driveBanco.setUsername("umewjtliplk0kq8l");
		driveBanco.setPassword("n9v8gv8CANwbmBJLo5rD");
		return driveBanco;
	}
	@Bean
	public JpaVendorAdapter jpaVendorAdapter() {
		HibernateJpaVendorAdapter adapter = new HibernateJpaVendorAdapter();
		adapter.setDatabase(Database.MYSQL);
		adapter.setShowSql(true);
		adapter.setGenerateDdl(true);
		adapter.setDatabasePlatform("org.hibernate.dialect.MySQL8Dialect");
		adapter.setPrepareConnection(true);
		return adapter;
	}
}
