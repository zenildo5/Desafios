package br.atos.cadastro_progamadores.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.atos.cadastro_progamadores.model.*;
import br.atos.cadastro_progamadores.repository.ProgramadorRepository;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ProgrmadorController {

	@Autowired
	ProgramadorRepository programadorRepository;
	
	@GetMapping("/programadores")
	public List<Programador> listarProgramador(){
	
		List<Programador> programadores = programadorRepository.findAll();
		return programadores;
	}
	
	@GetMapping(value = "/obterProgramador/{id}")
	public Programador obterProgramador(@PathVariable Long id) {
		Programador programador = programadorRepository.findById(id).orElse(new Programador());
		return programador;
	}
	@PostMapping(value = "/inserirProgramador")
	public void inserirProgramador(@RequestBody Programador programador) {
		programadorRepository.save(programador);
	}
	
	@DeleteMapping(value = "excluirProgramador/{id}")
	public void excluirProgramador(@PathVariable long id) {
	  programadorRepository.deleteById(id);
	}
	@PutMapping(value = "/alterarProgramador")
	public void alterarProgramador(@RequestBody Programador programador) {
		programadorRepository.save(programador);
	}
}
