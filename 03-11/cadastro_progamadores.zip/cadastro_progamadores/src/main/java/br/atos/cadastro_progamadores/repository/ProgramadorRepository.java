package br.atos.cadastro_progamadores.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import br.atos.cadastro_progamadores.model.Programador;

public interface ProgramadorRepository extends CrudRepository<Programador, Long>{
	List<Programador> findAll();
	//Programador findById(Long id);
}
