package br.atos.cadastro_progamadores.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_programador")
public class Programador implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idProgramador;
    public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	private String nome;
    private double salario;
    private int idade;
    
	public long getIdProgramador() {
		return idProgramador;
	}
	public void setIdProgramador(long idProgramador) {
		this.idProgramador = idProgramador;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
