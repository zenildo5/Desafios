package br.atos.model;

public class Coordenador extends Funcionario{
	private String loja;
	private Double metaloja;
	
	public String getLoja() {
		return loja;
	}
	public void setLoja(String loja) {
		this.loja = loja;
	}
	public Double getMetaloja() {
		return metaloja;
	}
	public void setMetaloja(Double metaloja) {
		this.metaloja = metaloja;
	}
	@Override
	protected Double calcularSalario(Integer qtdHoras) {
		return (40 * qtdHoras) * 0.93;
	}
	
}