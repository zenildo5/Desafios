package br.atos.telas;

import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import br.atos.controleTelas.ListaControle;
import br.atos.model.Coordenador;

public class Listar {
	JFrame frameTela = new JFrame();
	JPanel panelTela = new JPanel();
	JFrame frameMenu;
	
	public Listar(JFrame frameMenu) {
		this.frameMenu = frameMenu;
	}

	public void ExibirTela() {
		this.frameTela.setSize(500, 500);
		frameTela.add(panelTela);
		JLabel labelExcluir = new JLabel("CPF ");
		JTextField textFieldAlteracao = new JTextField(20);		
		
		
		ListaControle listaControle = new ListaControle(textFieldAlteracao,frameTela,frameMenu);
		
		ArrayList<Coordenador> lista = listaControle.ListarCoordenador();
		
		String [][] linhas = new String[lista.size()][5];
		int posicaoLinha = 0;
		int posicaoColuna = 0;
		
		for(Coordenador item: lista) {
			linhas[posicaoLinha][posicaoColuna] = item.getNome();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = item.getCpf();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = item.getSalario().toString();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = item.getLoja();
			posicaoColuna++;
			linhas[posicaoLinha][posicaoColuna] = String.valueOf(item.getMetaloja());
			posicaoColuna = 0;
			posicaoLinha++;
		}
		String[] colunasTitulo = {"Nome", "CPF", "Salario","Loja","Meta_Loja"};
		JTable tabela = new JTable(linhas,colunasTitulo);
		//tabela.setBounds(30,40,200,300);
		
		JScrollPane scroll = new JScrollPane(tabela);
		scroll.setBounds(30,40,200,300);
		panelTela.add(scroll);
		panelTela.add(tabela);
		
		JButton buttonExcluir = new JButton("Excluir");
		JButton buttonAlterar = new JButton("Alterar");
		buttonExcluir.addActionListener(listaControle);
		buttonAlterar.addActionListener(listaControle);
		
		panelTela.add(labelExcluir);
		panelTela.add(textFieldAlteracao);
		panelTela.add(buttonExcluir);
		panelTela.add(buttonAlterar);
		
		frameTela.setVisible(true);
		
	}
}
