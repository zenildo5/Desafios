package br.atos.telas;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.atos.controleTelas.MenuInicialControle;

public class MenuPrincipal {
	
	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	
	public MenuPrincipal() {
		frame.setSize(200, 200);
		frame.setTitle("Menu");
		frame.setLocation(400, 400);
		
		JLabel Menu1 = new JLabel("1 - Cadastrar Gerente");
		JLabel Menu2 = new JLabel("2 - Listar / Editar / Excluir");
		JLabel Menu3 = new JLabel("3 - Para Sair");
		
		panel.add(Menu1);
		panel.add(Menu2);
		panel.add(Menu3);
		
		JTextField textMenu = new JTextField(10);
		panel.add(textMenu);
		
		JButton botao = new JButton("Enviar");
		
		MenuInicialControle controle = new MenuInicialControle(textMenu, frame);
		botao.addActionListener(controle);
		
		panel.add(botao);
		frame.add(panel);
		
		frame.setVisible(true);
	}
}
