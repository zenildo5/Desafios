package br.atos.contraldor;

import br.atos.telas.MenuPrincipal;

public class RegistroControlador {
	
	public void IniciarPrograma() {
		MenuPrincipal mp = new MenuPrincipal();
	}
}
